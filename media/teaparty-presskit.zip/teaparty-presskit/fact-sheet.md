# TeaParty Game Studio · Fact sheet

**Indie studio making games you play with friends, most of them free in your browser.**
Pour a cup, press start.

| | |
|---|---|
| Studio | TeaParty Game Studio |
| Founder and developer | Juan Neyra |
| Engine and tools | Unity 6 (C#), Blender, local AI tooling for the pipeline. No generative AI in game art or screenshots. |
| Games | 5 playable today, 1 in development |
| Website | https://kurusudes.github.io |
| itch.io | https://teapartygamestudio.itch.io |
| GitHub | https://github.com/KurusuDes |
| Instagram | https://www.instagram.com/teapartygamestudio_oficial/ |
| TikTok | https://www.tiktok.com/@teapartygamestudio |
| X | https://x.com/teapartystd |
| YouTube | https://www.youtube.com/@teapartygamestudio |

## Games

### Inflation! Co-op Idle RPG
- **What it is:** a co-op RPG where the numbers never stop growing. One won fight pays out billions of EXP. Friends join with a room code to explore six rings, hunt bosses and take down the dragon together.
- **Status:** playable demo, in development.
- **Platform:** browser (itch.io), no account needed.
- **Year:** 2026.
- **Link:** https://teapartygamestudio.itch.io/inflation-coop-rpg

### Blobvarium
- **What it is:** a new Inca creature is born every day, drawn 100% by code from a seed, and you win it in a coin auction. Fuse them, raise them, sing with them and grow a town.
- **Status:** live.
- **Platform:** browser, desktop and phone.
- **Year:** 2026.
- **Numbers:** 100 players · 333+ blobis · 36+ fusions.
- **Link:** https://blobvarium.com

### Axie Darkness Arise
- **What it is:** a roguelite card battler where every body part of your creature is a card you aim across a ring-shaped arena. Solo or online co-op.
- **Status:** out on itch.io.
- **Platform:** Windows and browser.
- **Years:** 2023 (game jam) · 2026 (revived).
- **Award:** 4th place, Sky Mavis Game Jam 2023.
- **Numbers:** 35k lines of C#.
- **Link:** https://teapartygamestudio.itch.io/axie-darkness-arise
- Unofficial fan game. Axie Infinity art and music © Sky Mavis.

### Feeling Lucky?
- **What it is:** one magic sniper, one nine-sided die and a kaiju walking toward a town. Secure the damage or push your luck to double it.
- **Status:** game jam entry, playable.
- **Platform:** browser (WebGL).
- **Year:** 2026, made for the Official 2026 Unity Game Jam (theme: "Lucky Number").
- **Link:** https://teapartygamestudio.itch.io/feeling-lucky

### Katanittes
- **What it is:** a settlers game in the browser, with bots, online matches with friends, a 3D board, a map editor and modes like blindfold and fog of war.
- **Status:** playable.
- **Platform:** browser.
- **Year:** 2026.
- **Link:** https://kurusudes.github.io/CatanTestFriendos/

### MoriMonchis
- **What it is:** creatures bred through genetics, where every body part is inherited with its own odds. Raise them in a magic shop, then send a team of three on expeditions.
- **Status:** in development.
- **Platform:** Unity 6.
- **Years:** 2025–2026.

## Team experience
- **Little Sim World** (Blue Gravity Studios), shipped on Steam: Juan worked on it for 4 months in 2023 as a contract Unity developer. It is not a TeaParty game.

## In this kit
- `logos/`: the TeaParty logo, the horizontal logo, the cup and the profile icon, as PNG with transparency (cream for dark backgrounds, navy for light ones).
- `screenshots/`: 3 real gameplay screenshots per game.

Logo palette: navy `#141625` · cream `#F8EED8` · gold `#F2BB70`.
